#include <iostream>
#include <vector>
#include <cstring>
#include <unordered_map>
using namespace std;

struct record { 
	string packno, boxcode, itemcode; // �����ţ�����룬���ϱ���
	int itemqty; // ��װ����
};

class Solution {
	vector<record> recordList;
public:
	void gen_inverted_index() {
		FILE* fp = fopen("a.txt", "r");
		if (!fp) {
			cerr << "a.txt file open fails.\n";
		}
		record r;
		unordered_map<pair<string,string>, int> itemcode_packno_qty;
		while (fscanf(fp, "%s,%s,%s,%d\n", &r.packno, &r.boxcode, &r.itemcode, &r.itemqty) != EOF) {
			// ͳ��ͬһ���ϱ���ͬһ����������
			itemcode_packno_qty[{r.itemcode, r.packno}] += r.itemqty;
		}
		unordered_map<pair<string, int>, vector<string>> invertedIndexMap;
		fp = fopen("b.txt", "w");
		if (!fp) {
			cerr << "b.txt file open fails.\n";
		}
		for (auto&& i : itemcode_packno_qty) { // ����������ֵ
			invertedIndexMap[{i.first.first, i.second}].push_back(i.first.second);
		}
		for (auto&& i : invertedIndexMap) {
			fprintf(fp,"(%s,%d) -> [", i.first.first, i.first.second);
			//cout << "(" << i.first.first << ", " << i.first.second << ") -> [";
			for (auto&& j : i.second) {
				fprintf(fp, "%s, ", j);
				//cout << j << ", ";
			}
			fprintf(fp, "]\n");
			//cout << "]\n";
		}
		
	}
};
int main() {
	Solution s;
	s.gen_inverted_index();
	return 0;
}