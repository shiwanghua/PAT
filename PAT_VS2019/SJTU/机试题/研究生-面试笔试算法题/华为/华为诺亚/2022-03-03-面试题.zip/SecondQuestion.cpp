﻿
#include <iostream>
#include <vector>
#include<algorithm>
using namespace std;
class Solution {
	vector<vector<vector<int>>> ans; // 最终的组合方案
	vector<bool> allo; // 记录分配了哪些数
	// path: 记录当前的分配情况
	// i: 当前打算分配第几个物体
	// k: 在qj组中分配了k个物体
	// 尝试从物体e开始放
	void dfs(vector<vector<int>> path, int i, int e, int qj, int k) {
		if (i == m + 1) {
			ans.emplace_back(path);
			return;
		}
		if (k == 0)  // 当前组还未分配内存和物体
			path.emplace_back(vector<int>());
		for (int j = e; j <= m - (q[qj] - path[qj].size()) + 1; j++) { // 剩下的数要足以填满q[qj]分组
			if (!allo[j]) {
				path[qj].emplace_back(j); // qj是目前path的最后一个组
				allo[j] = true;
				if (path[qj].size() == q[qj])   // 当前组满了
					dfs(path, i + 1, 1, qj + 1, 0); // 开始放下一个组, 从头开始尝试
				else dfs(path, i + 1, j + 1, qj, k + 1); // 继续放当前组, 从j+1开始尝试
				path[qj].pop_back(); // 退回放之前的状态
				allo[j] = false;
			}
		}
		if (k == 0) // path是引用，需要退回之前状态
			path.pop_back();
	}
public:
	vector<int> q = { 3,5,4 };
	int m;
	vector<vector<vector<int>>> solution(int mm) {
		m = mm;
		allo.resize(m + 1);
		vector<vector<int>> path;
		dfs(path, 1, 1, 0, 0);
		for (auto&& a : ans) {
			std::cout << "[ ";
			for (auto&& p : a) {
				std::cout << "(";
				for (auto&& i : p)
					std::cout << i << ", ";
				std::cout << "),";
			}
			std::cout << " ]\n";
		}
		std:: cout <<"The number of combination: " << ans.size()<<"\n";
		return ans;
	}
};

int main2() {
	Solution s;
	s.solution(12);
	system("pause");
	return 0;
}